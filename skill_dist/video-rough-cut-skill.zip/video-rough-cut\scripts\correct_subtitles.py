"""LLM-based subtitle text correction without changing timestamps."""

from __future__ import annotations

import json
import re
from difflib import SequenceMatcher
from pathlib import Path

from core.utils import load_config, setup_logger
from providers.aliyun_qwen import AliyunQwenProvider
from schemas.models import Transcript, TranscriptSegment

logger = setup_logger(__name__)


def correct_subtitle_text(
    transcript: Transcript,
    prompt_template_path: Path,
) -> Transcript:
    cfg = load_config().get("subtitle_correction", {})
    if not bool(cfg.get("enabled", True)):
        return transcript
    max_segment_chars = int(cfg.get("max_segment_chars", 120))
    max_length_ratio = float(cfg.get("max_length_ratio", 1.6))
    min_similarity = float(cfg.get("min_similarity", 0.45))
    chunk_size = max(1, int(cfg.get("chunk_size", 12)))
    provider = AliyunQwenProvider()
    prompt_template = prompt_template_path.read_text(encoding="utf-8")
    corrections = []
    try:
        for chunk in _chunks(transcript.segments, chunk_size):
            payload = {
                "segments": [
                    {
                        "segment_id": seg.id,
                        "start": seg.start,
                        "end": seg.end,
                        "text": seg.text[:max_segment_chars],
                    }
                    for seg in chunk
                ]
            }
            prompt = f"{prompt_template}\n\n输入:\n{json.dumps(payload, ensure_ascii=False)}"
            result = provider.semantic_dedup(prompt)
            chunk_corrections = result.get("segments", [])
            if not isinstance(chunk_corrections, list):
                logger.warning("Subtitle correction returned invalid segments for a chunk; keeping that chunk original")
                continue
            corrections.extend(chunk_corrections)
    except Exception as exc:
        logger.warning("Subtitle correction failed; using original transcript text: %s", exc)
        return transcript

    text_by_id = {
        str(item.get("segment_id")): str(item.get("text", "")).strip()
        for item in corrections
        if isinstance(item, dict)
    }

    corrected_segments: list[TranscriptSegment] = []
    changed = 0
    rejected = 0
    for seg in transcript.segments:
        corrected = text_by_id.get(seg.id, "").strip()
        if _valid_correction(seg.text, corrected, max_length_ratio, min_similarity):
            text = corrected
            if text != seg.text:
                changed += 1
        else:
            if corrected:
                rejected += 1
            text = seg.text
        corrected_segments.append(
            TranscriptSegment(
                id=seg.id,
                start=seg.start,
                end=seg.end,
                text=text,
                words=seg.words,
            )
        )
    logger.info("Subtitle correction changed %d/%d segments", changed, len(corrected_segments))
    if rejected:
        logger.info("Subtitle correction rejected %d unsafe candidate(s)", rejected)
    return Transcript(language=transcript.language, segments=corrected_segments)


def _valid_correction(original: str, corrected: str, max_length_ratio: float, min_similarity: float) -> bool:
    if not corrected:
        return False
    original_len = max(1, len(original.strip()))
    corrected_len = len(corrected)
    if corrected_len > original_len * max_length_ratio:
        return False
    if corrected_len < original_len / max_length_ratio:
        return False
    similarity = SequenceMatcher(None, _normalize_text(original), _normalize_text(corrected)).ratio()
    if similarity < min_similarity:
        return False
    corrected_norm = _normalize_text(corrected)
    for phrase in _number_phrases(original):
        if phrase not in corrected_norm:
            return False
    return True


def _normalize_text(text: str) -> str:
    return "".join(ch for ch in text.strip().lower() if ch.isalnum() or "\u4e00" <= ch <= "\u9fff")


def _number_phrases(text: str) -> list[str]:
    norm = _normalize_text(text)
    phrases = re.findall(r"[0-9一二三四五六七八九十百千万亿两零〇]{2,}", norm)
    return [phrase for phrase in phrases if not (len(phrase) == 2 and phrase.endswith("月"))]


def _chunks(items: list[TranscriptSegment], size: int):
    for i in range(0, len(items), size):
        yield items[i : i + size]
