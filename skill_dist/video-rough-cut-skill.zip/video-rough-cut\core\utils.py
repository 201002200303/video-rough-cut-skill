"""Shared utilities for the video rough-cut skill."""

from __future__ import annotations

import logging
import os
import sys
from pathlib import Path
from typing import Any

import yaml

try:
    from dotenv import load_dotenv
except ImportError:  # pragma: no cover - dependency fallback for lean local test envs
    def load_dotenv(*args, **kwargs) -> bool:
        return False


class SkillError(Exception):
    """Base class for skill errors."""


class ExternalCommandError(SkillError):
    """Raised when an external command such as FFmpeg fails."""


class ProviderError(SkillError):
    """Raised when an ASR or LLM provider call fails."""


class ValidationError(SkillError):
    """Raised when input validation fails."""


class ConfigError(SkillError):
    """Raised when configuration is invalid or missing."""


_DEFAULT_CONFIG_PATH = Path(__file__).resolve().parent.parent / "config.default.yaml"
_cached_config: dict[str, Any] | None = None


def setup_logger(name: str, level: str = "INFO") -> logging.Logger:
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(
        logging.Formatter(
            fmt="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
    )
    logger.addHandler(handler)
    logger.setLevel(level.upper())
    return logger


def load_config() -> dict[str, Any]:
    global _cached_config
    if _cached_config is not None:
        return _cached_config

    if not _DEFAULT_CONFIG_PATH.exists():
        raise ConfigError(f"Default config not found: {_DEFAULT_CONFIG_PATH}")

    base = yaml.safe_load(_DEFAULT_CONFIG_PATH.read_text(encoding="utf-8"))
    env_config_path = os.getenv("VIDEO_SKILL_CONFIG")
    if env_config_path:
        path = Path(env_config_path)
        if not path.exists():
            raise ConfigError(f"VIDEO_SKILL_CONFIG path not found: {path}")
        overlay = yaml.safe_load(path.read_text(encoding="utf-8"))
        if overlay:
            deep_merge(base, overlay)

    _cached_config = base
    return base


def reload_config() -> dict[str, Any]:
    global _cached_config
    _cached_config = None
    return load_config()


def load_env() -> None:
    env_path = Path(__file__).resolve().parent.parent / ".env"
    if env_path.exists():
        load_dotenv(env_path)
    else:
        load_dotenv()


def deep_merge(base: dict, overlay: dict) -> None:
    for key, value in overlay.items():
        if key in base and isinstance(base[key], dict) and isinstance(value, dict):
            deep_merge(base[key], value)
        else:
            base[key] = value


def ensure_output_dir(output_dir: str) -> Path:
    if not output_dir:
        raise ValidationError("output_dir must not be empty")
    path = Path(output_dir)
    path.mkdir(parents=True, exist_ok=True)
    return path


def job_output_paths(output_dir: str) -> dict[str, Path]:
    directory = ensure_output_dir(output_dir)
    return {
        "audio": directory / "audio.wav",
        "vad_segments": directory / "vad_segments.json",
        "transcript": directory / "transcript.json",
        "semantic_segments": directory / "semantic_segments.json",
        "utterance_units": directory / "utterance_units.json",
        "edit_decisions": directory / "edit_decisions.json",
        "transcript_before_edit": directory / "transcript_before_edit.md",
        "transcript_after_edit": directory / "transcript_after_edit.md",
        "remapped_transcript": directory / "remapped_transcript.json",
        "subtitles": directory / "subtitles.ass",
        "visual_metadata": directory / "visual_metadata.json",
        "visual_overlay_ass": directory / "visual_overlay.ass",
        "cover_ass": directory / "cover.ass",
        "cover_image": directory / "cover.png",
        "edited_video": directory / "edited_video_with_yellow_subtitles.mp4",
        "report": directory / "edit_report.md",
    }


ARTIFACT_NAMES = {
    "audio": "audio.wav",
    "vad_segments": "vad_segments.json",
    "transcript": "transcript.json",
    "semantic_segments": "semantic_segments.json",
    "utterance_units": "utterance_units.json",
    "edit_decisions": "edit_decisions.json",
    "transcript_before_edit": "transcript_before_edit.md",
    "transcript_after_edit": "transcript_after_edit.md",
    "remapped_transcript": "remapped_transcript.json",
    "subtitles": "subtitles.ass",
    "visual_metadata": "visual_metadata.json",
    "visual_overlay_ass": "visual_overlay.ass",
    "cover_ass": "cover.ass",
    "cover_image": "cover.png",
    "edited_video": "edited_video_with_yellow_subtitles.mp4",
    "report": "edit_report.md",
}
